import { useState } from "react";
import "./styles.css";

export default function App() {
  const [count, setCount] = useState(0);

  const IncrementCount = () => {
    if (count >= 20) {
      setCount(0);
    } else {
      setCount((Count) => Count + 1);
    }
  };

  const DecrementCount = () => {
    if (count <= 0) {
      setCount(0);
    } else {
      setCount((count) => count - 1);
    }
  };

  return (
    <div className="APP">
      <h2 style={{ color: "red" }}>Counter APP</h2>
      <h1 style={{ color: "blue" }}>{count}</h1>
      <button style={{ color: "green" }} onClick={IncrementCount}>
        Increment
      </button>
      <button onClick={DecrementCount}>Decrement</button>
    </div>
  );
}
